package com.example.data

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow

object FirebaseManager {
    private val db: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Firebase not initialized: ${e.message}")
            null
        }
    }
    
    val appSettingsFlow = MutableStateFlow(AppSettings())
    
    fun listenToAppSettings() {
        db?.collection("app_settings")?.document("general")
            ?.addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w("FirebaseManager", "Listen failed.", e)
                    return@addSnapshotListener
                }
                
                if (snapshot != null && snapshot.exists()) {
                    val settings = AppSettings(
                        appVersion = snapshot.getString("appVersion") ?: "2.0.1",
                        lastUpdated = snapshot.getString("lastUpdated") ?: "January 2026",
                        aiTechnology = snapshot.getString("aiTechnology") ?: "Study AI",
                        supportedSubjects = snapshot.getString("supportedSubjects") ?: "15+",
                        developerName = snapshot.getString("developerName") ?: "Sunil Meghwal",
                        splashScreenLogoUrl = snapshot.getString("splashScreenLogoUrl") ?: "",
                        dailyFreeCreditsLimit = snapshot.getLong("dailyFreeCreditsLimit")?.toInt() ?: 25,
                        instagramUrl = snapshot.getString("instagramUrl") ?: "",
                        telegramUrl = snapshot.getString("telegramUrl") ?: "",
                        appShareUrl = snapshot.getString("appShareUrl") ?: "",
                        developerInfo = snapshot.getString("developerInfo") ?: "Developer by Sunil Meghwal",
                        privacyPolicy = snapshot.getString("privacyPolicy") ?: ""
                    )
                    appSettingsFlow.value = settings
                }
            }
    }
    
    fun syncUser(settings: UserSettings) {
        if (settings.userId.isEmpty()) return
        
        val userMap = hashMapOf(
            "id" to settings.userId,
            "name" to settings.name,
            "userClass" to settings.userClass,
            "credits" to settings.credits,
            "status" to settings.status
        )
        
        db?.collection("users")?.document(settings.userId)
            ?.set(userMap)
            ?.addOnSuccessListener { Log.d("FirebaseManager", "User synced successfully") }
            ?.addOnFailureListener { e -> Log.w("FirebaseManager", "Error syncing user", e) }
    }
    
    fun listenToUserUpdates(userId: String, onUpdate: (Int, String) -> Unit) {
        if (userId.isEmpty()) return
        db?.collection("users")?.document(userId)
            ?.addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w("FirebaseManager", "Listen user failed.", e)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val credits = snapshot.getLong("credits")?.toInt()
                    val status = snapshot.getString("status")
                    if (credits != null && status != null) {
                        onUpdate(credits, status)
                    }
                }
            }
    }
    
    fun syncHistory(userId: String, historyItem: HistoryItem) {
        if (userId.isEmpty()) return
        
        val historyMap = hashMapOf(
            "question" to historyItem.question,
            "answer" to historyItem.answer,
            "language" to historyItem.language,
            "timestamp" to historyItem.timestamp
        )
        
        db?.collection("users")?.document(userId)
            ?.collection("history")?.document(historyItem.timestamp.toString())
            ?.set(historyMap)
    }
    
    fun requestSubject(userId: String, userName: String, subjectName: String) {
        val requestMap = hashMapOf(
            "userId" to userId,
            "userName" to userName,
            "subjectName" to subjectName,
            "timestamp" to System.currentTimeMillis()
        )
        db?.collection("subject_requests")?.add(requestMap)
    }
}
