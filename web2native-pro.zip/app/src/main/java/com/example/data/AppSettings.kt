package com.example.data

data class AppSettings(
    val appVersion: String = "2.0.1",
    val lastUpdated: String = "January 2026",
    val aiTechnology: String = "Study AI",
    val supportedSubjects: String = "15+",
    val developerName: String = "Sunil Meghwal",
    val splashScreenLogoUrl: String = "",
    val dailyFreeCreditsLimit: Int = 25,
    val instagramUrl: String = "",
    val telegramUrl: String = "",
    val appShareUrl: String = "",
    val developerInfo: String = "Developer by Sunil Meghwal",
    val privacyPolicy: String = ""
)
