package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.Candidate
import com.example.api.Content

import com.example.api.OpenRouterClient
import com.example.api.OpenRouterRequest
import com.example.api.OpenRouterRequestMessage
import com.example.api.OpenRouterMessageContent
import com.example.api.OpenRouterImageUrl

import com.example.api.InlineData
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.data.ChatMessage
import com.example.data.HistoryItem
import com.example.data.StudyRepository
import com.example.data.UserSettings
import com.example.data.FirebaseManager
import com.example.data.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class StudyViewModel(private val repository: StudyRepository) : ViewModel() {
    val appSettings = FirebaseManager.appSettingsFlow
    private var isListeningUser = false
    val userSettings: StateFlow<UserSettings?> = repository.userSettings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )
    
    init {
        FirebaseManager.listenToAppSettings()
        viewModelScope.launch {
            userSettings.collect { settings ->
                if (settings != null && settings.userId.isNotEmpty()) {
                    FirebaseManager.syncUser(settings)
                    if (!isListeningUser) {
                        isListeningUser = true
                        FirebaseManager.listenToUserUpdates(settings.userId) { credits, status ->
                            val current = userSettings.value
                            if (current != null && (credits != current.credits || status != current.status)) {
                                viewModelScope.launch { repository.saveUserSettings(current.copy(credits = credits, status = status)) }
                            }
                        }
                    }
                }
            }
        }
    }

    val history: StateFlow<List<HistoryItem>> = repository.allHistory.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val chatMessages: StateFlow<List<ChatMessage>> = repository.chatMessages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading
    
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun clearError() {
        _error.value = null
    }

    fun saveSettings(settings: UserSettings) {
        viewModelScope.launch {
            repository.saveUserSettings(settings)
        }
    }

    fun toggleFavoriteSubject(subjectId: String) {
        val currentSettings = userSettings.value ?: return
        val currentFavorites = currentSettings.favoriteSubjects.split(",").filter { it.isNotEmpty() }.toMutableSet()
        if (currentFavorites.contains(subjectId)) {
            currentFavorites.remove(subjectId)
        } else {
            currentFavorites.add(subjectId)
        }
        val newFavoritesStr = currentFavorites.joinToString(",")
        saveSettings(currentSettings.copy(favoriteSubjects = newFavoritesStr))
    }

    fun requestSubject(subjectName: String) {
        val current = userSettings.value ?: return
        if (current.userId.isNotEmpty()) {
            FirebaseManager.requestSubject(current.userId, current.name, subjectName)
        }
    }

    fun completeSetup(name: String, userClass: String, language: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            val newUserId = if (current.userId.isEmpty()) "user_${System.currentTimeMillis()}_${(10000..99999).random()}" else current.userId
            repository.saveUserSettings(
                current.copy(
                    userId = newUserId,
                    name = name,
                    userClass = userClass,
                    language = language,
                    setupCompleted = true
                )
            )
        }
    }
    
    fun deductCredit() {
        viewModelScope.launch {
            val current = userSettings.value ?: return@launch
            if (current.credits > 0) {
                repository.saveUserSettings(current.copy(credits = current.credits - 1))
            }
        }
    }

    fun checkAndResetCredits() {
        viewModelScope.launch {
            val current = userSettings.value ?: return@launch
            
            val lastResetCal = java.util.Calendar.getInstance()
            lastResetCal.timeInMillis = current.lastCreditReset
            
            val nowCal = java.util.Calendar.getInstance()
            
            val isSameDay = lastResetCal.get(java.util.Calendar.YEAR) == nowCal.get(java.util.Calendar.YEAR) &&
                            lastResetCal.get(java.util.Calendar.DAY_OF_YEAR) == nowCal.get(java.util.Calendar.DAY_OF_YEAR)
            
            if (!isSameDay) {
                // Reset daily free credits up to 20. If they have more than 20 (e.g. bought), leave them as is.
                val limit = appSettings.value.dailyFreeCreditsLimit
                val newCredits = kotlin.math.max(limit, current.credits)
                repository.saveUserSettings(current.copy(credits = newCredits, lastCreditReset = System.currentTimeMillis()))
            }
        }
    }

    fun addCredits(amount: Int) {
        viewModelScope.launch {
            val current = userSettings.value ?: return@launch
            repository.saveUserSettings(current.copy(credits = current.credits + amount))
        }
    }

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        // Resize bitmap if too large to save tokens
        val maxDim = 1024
        val ratio = kotlin.math.min(maxDim.toFloat() / width, maxDim.toFloat() / height)
        val resized = if (ratio < 1) {
            Bitmap.createScaledBitmap(this, (width * ratio).toInt(), (height * ratio).toInt(), true)
        } else {
            this
        }
        resized.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun getSolverAnswer(
        subject: String,
        question: String,
        image: Bitmap?,
        lang: String,
        onSuccess: (String) -> Unit
    ) {
        _isLoading.value = true
        val currentUser = userSettings.value
        if (currentUser?.status == "Banned") {
            _error.value = "Your account has been banned."
            _isLoading.value = false
            return
        }
        _error.value = null
        try {
            val apiKey = com.example.BuildConfig.GEMINI_API_KEY
            if (false) {
                _error.value = "API Key is missing. Please configure it in Secrets."
                return
            }

            val parts = mutableListOf<Part>()
            val langInstruction = if (lang == "hi") "Regardless of the language I asked in, you MUST answer entirely in Hindi." else "Regardless of the language I asked in, you MUST answer entirely in English."
            var promptText = "Subject: $subject. "
            if (question.isNotEmpty()) {
                promptText += "Question: $question. "
            } else if (image != null) {
                promptText += "Analyze the provided image and solve the problem or describe it. "
            }
            promptText += langInstruction
            
            parts.add(Part(text = promptText))
            
            if (image != null) {
                parts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = image.toBase64())))
            }

            val finalPrompt = "You are a helpful tutor. Provide a very short, direct, and simple final answer to the student.\n" + promptText
            val msgContents = mutableListOf<OpenRouterMessageContent>()
            msgContents.add(OpenRouterMessageContent(type = "text", text = finalPrompt))
            if (image != null) {
                msgContents.add(OpenRouterMessageContent(type = "image_url", image_url = OpenRouterImageUrl("data:image/jpeg;base64,${image.toBase64()}")))
            }
            val requestMessages = listOf(OpenRouterRequestMessage(role = "user", content = msgContents))
            val answer = fetchFromOpenRouter(requestMessages)
            
            if (answer != null) {
                val historyItem = HistoryItem(question = question.ifEmpty { "Image Question" }, answer = answer, language = lang)
                repository.insertHistoryItem(historyItem)
                userSettings.value?.userId?.takeIf { it.isNotEmpty() }?.let { uid -> FirebaseManager.syncHistory(uid, historyItem) }
                deductCredit()
                onSuccess(answer)
            } else {
                _error.value = "Failed: API Error"
            }
        } catch (e: Exception) {
            _error.value = "Error: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun explainAnswer(answer: String, lang: String, onSuccess: (String) -> Unit) {
        _isLoading.value = true
        val currentUser = userSettings.value
        if (currentUser?.status == "Banned") {
            _error.value = "Your account has been banned."
            _isLoading.value = false
            return
        }
        _error.value = null
        try {
            val apiKey = com.example.BuildConfig.GEMINI_API_KEY
            val langInstruction = if (lang == "hi") "Regardless of the language I asked in, you MUST explain entirely in Hindi." else "Regardless of the language I asked in, you MUST explain entirely in English."
            val prompt = "Explain this answer in simple steps for a student: \"$answer\". $langInstruction Provide a clear, step-by-step breakdown that helps understand the concept. Do NOT use any special LaTeX math symbols like $$ or markdown symbols. Use plain text formatting and simple structure so anyone can understand."
            
            val msgContents = listOf(OpenRouterMessageContent(type = "text", text = prompt))
            val requestMessages = listOf(OpenRouterRequestMessage(role = "user", content = msgContents))
            val explanation = fetchFromOpenRouter(requestMessages)
            
            if (explanation != null) {
                onSuccess(explanation)
            } else {
                _error.value = "Failed: API Error"
            }
        } catch (e: Exception) {
            _error.value = "Error: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    suspend fun translateText(text: String, fromLang: String, toLang: String, onSuccess: (String) -> Unit) {
        _isLoading.value = true
        val currentUser = userSettings.value
        if (currentUser?.status == "Banned") {
            _error.value = "Your account has been banned."
            _isLoading.value = false
            return
        }
        _error.value = null
        try {
            val apiKey = com.example.BuildConfig.GEMINI_API_KEY
            val prompt = "Translate the following text from $fromLang to $toLang: \"$text\". Only provide the translation, no explanations."
            
            val msgContents = listOf(OpenRouterMessageContent(type = "text", text = prompt))
            val requestMessages = listOf(OpenRouterRequestMessage(role = "user", content = msgContents))
            val translation = fetchFromOpenRouter(requestMessages)
            
            if (translation != null) {
                onSuccess(translation)
            } else {
                _error.value = "Failed: API Error"
            }
        } catch (e: Exception) {
            _error.value = "Error: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    suspend fun sendChatMessage(message: String, lang: String, onSuccess: (String) -> Unit = {}) {
        _isLoading.value = true
        val currentUser = userSettings.value
        if (currentUser?.status == "Banned") {
            _error.value = "Your account has been banned."
            _isLoading.value = false
            return
        }
        _error.value = null
        try {
            val apiKey = com.example.BuildConfig.GEMINI_API_KEY
            repository.insertChatMessage(ChatMessage(role = "user", content = message))
            deductCredit()
            
            val langContext = if (lang == "hi") "Regardless of the user's language, you MUST reply entirely in Hindi." else "Regardless of the user's language, you MUST reply entirely in English."
            val sysInstruction = "You are a helpful AI study assistant. $langContext"
            
            val currentHistory = chatMessages.value.takeLast(10).filter { it.id > 0 } // exclude pending
            val historyStr = currentHistory.joinToString("\n") { val roleName = if (it.role == "ai") "AI" else "User"; "$roleName: ${it.content}" }
            
            val finalPrompt = "$sysInstruction\n\nHistory:\n$historyStr\n\nUser: $message\nAI:"
            val msgContents = listOf(OpenRouterMessageContent(type = "text", text = finalPrompt))
            val requestMessages = listOf(OpenRouterRequestMessage(role = "user", content = msgContents))
            val reply = fetchFromOpenRouter(requestMessages)
            
            if (reply != null) {
                repository.insertChatMessage(ChatMessage(role = "ai", content = reply))
                onSuccess(reply)
            } else {
                _error.value = "Failed: API Error"
            }
        } catch (e: Exception) {
            _error.value = "Error: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }


    private suspend fun fetchFromOpenRouter(messages: List<OpenRouterRequestMessage>): String? {
        val models = listOf(
            "google/gemini-2.0-flash-exp:free",
            "qwen/qwen-2.5-vl-72b-instruct:free",
            "meta-llama/llama-3.2-11b-vision-instruct:free",
            "openrouter/free",
            "nvidia/nemotron-nano-12b-v2-vl:free",
            "poolside/laguna-xs-2.1:free",
            "tencent/hy3:free"
        )
        val token = "Bearer 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"
        
        var lastError: Exception? = null
        for (model in models) {
            try {
                val request = OpenRouterRequest(model = model, messages = messages)
                val response = OpenRouterClient.service.generateContent(token, "https://studyai.example.com", request)
                val text = response.choices?.firstOrNull()?.message?.content
                if (!text.isNullOrEmpty()) {
                    return text
                }
            } catch (e: Exception) {
                lastError = e
            }
        }
        if (lastError != null) throw lastError
        return null
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    fun deleteHistoryItem(item: HistoryItem) {
        viewModelScope.launch {
            repository.deleteHistoryItem(item)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}

class StudyViewModelFactory(private val repository: StudyRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudyViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return StudyViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// Adding missing functions at the end before brace
